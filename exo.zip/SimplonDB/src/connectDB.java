import java.sql.*;


public class connectDB {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

            try {
                // connection to database
                Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/simplon","root","");
                
                //create statement
                Statement myStat = myConn.createStatement();
                
                //execute sql query
                ResultSet myRs = myStat.executeQuery("select * from siege");
                
                while(myRs.next()) {
                	System.out.println(myRs.getString(1) + ", " + myRs.getString(2) + ", " + myRs.getString(3) + ", " + myRs.getString(4) + ", " + myRs.getString(5));
                }
                
                
            } catch (SQLException e) {
                e.printStackTrace();
            }
        
    }

}