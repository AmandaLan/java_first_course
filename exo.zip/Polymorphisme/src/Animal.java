
public class Animal {
	public void crier() {
		System.out.println("un cri d'animal");
	}
}
