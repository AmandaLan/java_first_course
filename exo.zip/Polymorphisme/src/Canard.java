
public class Canard extends Animal {
	public void crier() {
		System.out.println("Couac !");
	}
}
