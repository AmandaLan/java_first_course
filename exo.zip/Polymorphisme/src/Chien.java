
public class Chien extends Animal {
	public void crier() {
		System.out.println("Ouaf !");
	}
}
