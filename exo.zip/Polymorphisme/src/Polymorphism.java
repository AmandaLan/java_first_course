
public class Polymorphism {

	public static void main(String[] args) {

		//utilisation du polymorphisme pour indiquer que chaque �l�ment de notre tableau(animal) ont un emplacment et notre tableau � un comportement g�n�rique et que c'est le comportement concr�t de chaque �l�ment qui seront appliqu�
		//surclassement = dans un emplacment de Animal tu stock un �l�ments, Animal est la superclass parent (Upcasting)
		Animal[] someAnimals = new Animal[3];
		someAnimals[0] = new Chien();
		someAnimals[1] = new Chat();
		someAnimals[2] = new Canard();
		
		for(Animal someAnimal:someAnimals) {
			someAnimal.crier();
		}

//		Animal animal = new Animal();
//		animal.crier(); // affiche "un cri d'animal"
//
//		Chat chat = new Chat();
//		chat.crier(); // affiche "Miaou !"
//
//		Chien chien = new Chien();
//		chien.crier(); // affiche "Whouaf whouaf !"
//
//		animal = chat;
//		animal.crier(); // affiche "Miaou !"
//
//		animal = chien;
//		animal.crier(); // affiche "Whouaf whouaf !"

	}

}
