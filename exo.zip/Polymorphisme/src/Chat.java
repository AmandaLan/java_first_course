
public class Chat extends Animal {
	public void crier() {
		System.out.println("Miaou !");
	}
}
